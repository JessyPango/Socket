package clientTest;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws ClassNotFoundException{
		
		Socket socketClient;
		ObjectOutputStream sortie;
		ObjectInputStream entree;
		
		Scanner sc = new Scanner(System.in) ;
		String ligne;
		
		try {
			
			socketClient = new Socket("localhost", 8189);
			
			try {
				sortie = new ObjectOutputStream(socketClient.getOutputStream());
				entree = new ObjectInputStream(socketClient.getInputStream());
	
				ligne = (String) entree.readObject();
				System.out.println(ligne);
				ligne = sc.nextLine();
				sortie.writeObject(ligne);
				
				while(true)
				{
					ligne = (String) entree.readObject();
					System.out.println(ligne);
					ligne = sc.nextLine();
					sortie.writeObject(ligne);
				}
				
			} finally {
				socketClient.close();
			}
		} catch (ConnectException e) {
			System.out.println("Le Serveur est indisponible! " + e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		

	}

}