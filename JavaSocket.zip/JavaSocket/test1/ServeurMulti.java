package test1;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class ServeurMulti extends Thread {
	
	public void run() {
		
		ServerSocket serveur;
		Boolean actif;
		Socket serveurSocket;
		Thread[] threadClients = new Thread[3];
		
		try 
		{
			serveur = new ServerSocket(8189);
			try 
			{
				serveur.setSoTimeout(10);
				actif = true;
				
				while(actif) 
				{
					try {
						serveurSocket = serveur.accept();
						
						// Probleme de sémaphore
						
						ThreadClient.nombreClient ++;
						threadClients[ThreadClient.nombreClient-1] = new ThreadClient(serveurSocket, ThreadClient.nombreClient);
						threadClients[ThreadClient.nombreClient-1].start();
					} 
					catch (SocketTimeoutException e) 
					{
						
						if( interrupted() ) 
						{
							actif = false;
							for(int i=0; i<=2; i++) {
								threadClients[i].interrupt();
							}
						} 
					}
				}
			} finally
			{
				System.out.println("Le serveur Multi veut arrêter!");
				serveur.close();
				System.out.println("Le serveur Multi c'est arrêter!");
			}
			
		} catch (BindException e) {
			System.out.println("Le serveur est déjà démarer!!! ---->"+e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} 
	}
}
