package test1;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class ThreadClient  extends Thread {
	public static int nombreClient=0;
	private int id;
	private Socket socketServeur;
	
	public ThreadClient(Socket socketServeur, int id) 
	{
		this.socketServeur = socketServeur;
		this.id = id;
	}
	
	public void run()
	{
		ObjectInputStream entree;
		ObjectOutputStream sortie;
		
		String ligne;
		Boolean actif = true;
		
		try {
			entree = new ObjectInputStream(socketServeur.getInputStream());
			sortie = new ObjectOutputStream(socketServeur.getOutputStream());
			
			socketServeur.setSoTimeout(10);
			
			while(actif) {
				
				try {
					
					sortie.writeObject("Bienvenue client " + id + " !");
					ligne = (String) entree.readObject();
					
					while(true) 
					{
						sortie.writeObject("Client " + id + " :" + ligne);
						ligne = (String) entree.readObject();
					}
					
				} catch (SocketTimeoutException e) {
					
					if ( interrupted() ) {
						
						sortie.writeObject("Le serveur s'arrête !!!");
						actif = false;
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				socketServeur.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}
}